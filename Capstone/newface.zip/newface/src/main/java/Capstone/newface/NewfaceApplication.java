package Capstone.newface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewfaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewfaceApplication.class, args);
	}

}
